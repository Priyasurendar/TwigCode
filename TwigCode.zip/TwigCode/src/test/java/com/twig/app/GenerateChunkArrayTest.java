package com.twig.app;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Created by Gowri Priya on 27/03/19.
 */
public class GenerateChunkArrayTest {

    GenerateChunkArray generateChunkArray;

    @Before
    public void addValues(){
        generateChunkArray = new GenerateChunkArray();

    }

    @Test
    public void testChunkArray() throws Exception {
        int[] numbers = {1, 2, 3, 4, 5};
        int[][] chunks = generateChunkArray.chunkArray(numbers,GenerateChunkArray.NUMBER_OF_CHUNKS);
        assertEquals(chunks.length , 3);
        assertEquals(chunks[0][0],1);
        assertEquals(chunks[0][1],2);
        assertEquals(chunks[2][0],5);
    }




}
