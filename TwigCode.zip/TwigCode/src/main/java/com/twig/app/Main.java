package com.twig.app; /**
 * Created by Gowri Priya on 26/03/19.
 */

import java.util.*;

public class Main {



    public static void main(String[] args) throws Exception {
        int[] numbers = {1, 2, 3, 4, 5};
        GenerateChunkArray generateChunkArray = new GenerateChunkArray();
        int[][] chunks = generateChunkArray.chunkArray(numbers,GenerateChunkArray.NUMBER_OF_CHUNKS);
        System.out.println(Arrays.deepToString(chunks));
    }

}