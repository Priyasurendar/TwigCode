package com.twig.app;

/**
 * Created by Gowri Priya on 27/03/19.
 */
public class GenerateChunkArray {
    public static final int NUMBER_OF_CHUNKS = 3;

    public int[][] chunkArray(int[] array, int numOfChunks ) throws Exception {

        int arrLength = array.length;
        int chunkSize = 0;
        if (arrLength - numOfChunks == 1) {
            throw new Exception("Incompatible value passed");
        } else if (arrLength % numOfChunks != 0) {
            chunkSize = Math.round(array.length / numOfChunks) + 1;
        } else {
            chunkSize = arrLength / numOfChunks;
        }
        int[][] output = new int[numOfChunks][];

        for (int i = 0; i < numOfChunks; ++i) {
            int start = i * chunkSize;
            int length = Math.min(array.length - start, chunkSize);

            int[] temp = new int[length];
            System.arraycopy(array, start, temp, 0, length);
            output[i] = temp;
        }
        return output;
    }


}
